The binary file "wartools" v3.3.2 has been taken from the wargus project.

- Release: https://github.com/Wargus/wargus/releases/tag/v3.3.2 (windows wartool.exe) respectively https://code.launchpad.net/~stratagus/+archive/ubuntu/ppa/+build/24277507 (linux wartool)
- Source Code: https://github.com/Wargus/wargus/tree/master
- Licence (see file COPYING taken from the source code repository): "GNU GENERAL PUBLIC LICENSE Version 2, June 1991"
